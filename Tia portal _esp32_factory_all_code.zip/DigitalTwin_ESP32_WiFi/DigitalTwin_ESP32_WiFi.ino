#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <OneWire.h>
#include <DallasTemperature.h>
// ===================== [WiFi ADD] =====================
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
// ======================================================

// =======================================================
// 1. إعدادات المحرك وسواقة BTS7960
// =======================================================
const int RPWM = 25;    
const int LPWM = 26;    
const int EN_PIN = 14;

const int freq = 15000;       
const int resolution = 8;     
int currentSpeed = 0;         
int speedStep = 5;            
int targetSpeed = 255;

// =======================================================
// [WiFi ADD] إعدادات WiFi وخادم Python Flask
// =======================================================
const char* WIFI_SSID   = "IdoomFibre_ATfF8X7zZ";     // ← غيّر هذا
const char* WIFI_PASS   = "yWgq99Hm";           // ← غيّر هذا
const char* PYTHON_IP   = "192.168.100.74";       // ← IP يظهر في terminal Python
const int   PYTHON_PORT = 5000;

// متغيرات مشتركة — تُحدَّث في بلوك 150ms وتُرسَل في بلوك 300ms
float wifi_ax = 0.0, wifi_ay = 0.0, wifi_az = 0.0;
float wifi_tempC    = 25.0;
float wifi_current  = 0.0;
unsigned long lastWiFi_Millis = 0;   // توقيت إرسال WiFi منفصل عن السيريال
// ======================================================

// =======================================================
// 2. إعدادات حساس السرعة (Slotted Encoder)
// =======================================================
const int ENCODER_PIN = 27;      
volatile int pulseCount = 0;     
unsigned long lastRPM_Millis = 0;    
float rpm = 0.0;                 
const int slotsInDisc = 20;      

void IRAM_ATTR countPulse() {
  pulseCount++;
}

// =======================================================
// 3. إعدادات حساس الاهتزاز MPU6050
// =======================================================
const int my_SDA = 32;        
const int my_SCL = 13;        
Adafruit_MPU6050 mpu;

// =======================================================
// 4. إعدادات حساس الحرارة DS18B20 (Non-Blocking)
// =======================================================
const int ONE_WIRE_BUS = 33; 
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
unsigned long lastTemp_Millis = 0;
float tempC = 25.0; 

// =======================================================
// 5. إعدادات حساس التيار ACS712 مع الـ ESP32
// =======================================================
const int CURRENT_PIN = 35; 
const float SENSITIVITY = 0.185; 

float actual_zero_voltage = 2.5; 

unsigned long lastSerial_Millis = 0;
String rxBuffer = "";


// =======================================================
// [WiFi ADD] دالة الاتصال بالشبكة
// =======================================================
void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("[WiFi] Connecting");
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30) {
    delay(500);
    Serial.print(".");
    tries++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi] Connected!");
    Serial.print("[WiFi] ESP32 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n[WiFi] FAILED — تأكد من SSID/Password");
  }
}

// =======================================================
// [WiFi ADD] دالة إرسال بيانات الحساسات لـ Flask + استقبال PWM
// =======================================================
void sendToFlask(float pwm, float rpmVal,
                 float vx,  float vy, float vz,
                 float tempVal, float currentVal) {

  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    return;
  }

  WiFiClient client;
  HTTPClient http;

  String url = "http://" + String(PYTHON_IP) + ":" + String(PYTHON_PORT) + "/telemetry";

  if (!http.begin(client, url)) {
    Serial.println("[WiFi] http.begin failed");
    return;
  }

  http.addHeader("Content-Type", "application/json");
  http.addHeader("Connection", "close");
  http.setTimeout(1500);

  StaticJsonDocument<256> doc;
  doc["Speed_PWM"] = pwm;
  doc["RPM"]       = rpmVal;
  doc["Vib_X"]     = vx;
  doc["Vib_Y"]     = vy;
  doc["Vib_Z"]     = vz;
  doc["Temp"]      = tempVal;
  doc["Current"]   = currentVal;

  String body;
  serializeJson(doc, body);

  int httpCode = http.POST(body);

  Serial.print("[WiFi] HTTP ");
  Serial.println(httpCode);

  if (httpCode == 200) {
    String response = http.getString();
    if (response.startsWith("PWM:")) {
      int newPwm = response.substring(4).toInt();
      if (newPwm >= 0 && newPwm <= 255 && newPwm != targetSpeed) {
        targetSpeed = newPwm;
        Serial.print("ACK_PWM:");
        Serial.println(targetSpeed);
      }
    }
  } else {
    Serial.print("[WiFi] Error: ");
    Serial.println(http.errorToString(httpCode));
  }

  http.end();
}
// ======================================================


void setup() {
  pinMode(EN_PIN, OUTPUT);
  digitalWrite(EN_PIN, LOW);

  Serial.begin(115200);
  while (!Serial); 

  Serial.println("\n--- Optimized Digital Twin Telemetry Core ---");

  // [WiFi ADD] الاتصال بالشبكة بعد Serial مباشرة
  connectWiFi();
  Serial.print("[WiFi] ESP32 IP: ");
  Serial.println(WiFi.localIP());
  WiFi.mode(WIFI_STA);
  // تهيئة MPU6050
  Wire.begin(my_SDA, my_SCL);
  if (!mpu.begin(0x68, &Wire)) { 
    Serial.println("Error: MPU6050 not found!");
  } else {
    mpu.setAccelerometerRange(MPU6050_RANGE_16_G); 
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }

  // تهيئة حساس الحرارة وجعله غير حاصِر (Non-Blocking)
  sensors.begin();
  sensors.setWaitForConversion(false); 
  sensors.requestTemperatures(); 

  // تهيئة حساس السرعة
  pinMode(ENCODER_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_PIN), countPulse, FALLING);

  // تهيئة المحرك وتأكيد توقفه عند الإقلاع
  ledcAttach(RPWM, freq, resolution);
  pinMode(LPWM, OUTPUT);
  digitalWrite(LPWM, LOW); 
  ledcWrite(RPWM, 0); 
  delay(500); 

  // [المعايرة الديناميكية لحساس التيار عند الإقلاع]
  long setupAdcSum = 0;
  for (int i = 0; i < 100; i++) { 
    setupAdcSum += analogRead(CURRENT_PIN);
    delay(5);
  }
  float avgSetupAdc = (float)setupAdcSum / 100.0;
  actual_zero_voltage = (avgSetupAdc * 3.3) / 4095.0;
  
  Serial.print("Calibrated Actual Zero Voltage: ");
  Serial.print(actual_zero_voltage, 4);
  Serial.println(" V");

  lastRPM_Millis = millis();
  lastTemp_Millis = millis();
  lastSerial_Millis = millis();
  lastWiFi_Millis = millis();   // [WiFi ADD]
}

void loop() {
  unsigned long currentMillis = millis();

  // =======================================================
  // 0. استقبال الأوامر من البايثون (حرف بحرف - 100% Non-Blocking)
  // =======================================================
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n') {
      rxBuffer.trim();
      if (rxBuffer.startsWith("SET_PWM:")) {
        int colonIndex = rxBuffer.indexOf(':');
        if (colonIndex != -1) {
          String valStr = rxBuffer.substring(colonIndex + 1);
          int newSpeed = valStr.toInt();
          if (newSpeed >= 0 && newSpeed <= 255) {
            targetSpeed = newSpeed;
            Serial.print("ACK_PWM:"); Serial.println(targetSpeed);
          }
        }
      }
      rxBuffer = "";
    } else if (c != '\r') {
      rxBuffer += c;
    }
  }

  // =======================================================
  // 1. التدرج الآمن في السرعة نحو الهدف والتوقف القسري
  // =======================================================
  static unsigned long lastSpeed_Millis = 0;
  if (currentMillis - lastSpeed_Millis >= 200) {
    
    if (targetSpeed == 0) {
      currentSpeed = 0;
      ledcWrite(RPWM, 0);
      digitalWrite(RPWM, LOW);
      digitalWrite(LPWM, LOW);
      digitalWrite(EN_PIN, LOW);
    } 
    else {
      digitalWrite(EN_PIN, HIGH);
      digitalWrite(LPWM, LOW);
      
      if (currentSpeed < targetSpeed) currentSpeed += speedStep;
      else if (currentSpeed > targetSpeed) currentSpeed -= speedStep;
      
      ledcWrite(RPWM, currentSpeed);
    }
    lastSpeed_Millis = currentMillis;
  }

  // =======================================================
  // 2. حساب السرعة الحقيقية RPM كل 500 مللي ثانية
  // =======================================================
  if (currentMillis - lastRPM_Millis >= 500) {
    detachInterrupt(digitalPinToInterrupt(ENCODER_PIN)); 
    
    unsigned long duration = currentMillis - lastRPM_Millis;
    float revolutions = (float)pulseCount / slotsInDisc;
    rpm = (revolutions / duration) * 60000.0;
    
    if (currentSpeed == 0) rpm = 0.0;
    
    pulseCount = 0;
    lastRPM_Millis = currentMillis;
    attachInterrupt(digitalPinToInterrupt(ENCODER_PIN), countPulse, FALLING);
  }

  // =======================================================
  // 3. طلب وتحديث الحرارة كل 2000 مللي ثانية (دون تأخير)
  // =======================================================
  if (currentMillis - lastTemp_Millis >= 2000) {
    tempC = sensors.getTempCByIndex(0); 
    sensors.requestTemperatures(); 
    lastTemp_Millis = currentMillis;
  }

  // =======================================================
  // 4. إرسال البيانات المجمعة للسيريال بمعدل ثابت (كل 150 مللي ثانية)
  // =======================================================
  if (currentMillis - lastSerial_Millis >= 150) {
    sensors_event_t a, g, temp_mpu;
    mpu.getEvent(&a, &g, &temp_mpu);

    long adcSum = 0;
    for (int i = 0; i < 40; i++) { 
      adcSum += analogRead(CURRENT_PIN);
      delayMicroseconds(30); 
    }
    float adcValue = (float)adcSum / 40.0; 
    float voltage = (adcValue * 3.3) / 4095.0; 
    
    float calculated_current = fabs((voltage - actual_zero_voltage) / SENSITIVITY);

    static float smoothed_current = 0.0;
    if (currentSpeed == 0) {
      smoothed_current = 0.0; 
    } else {
      smoothed_current = (0.15 * calculated_current) + (0.85 * smoothed_current);
    }

    if (smoothed_current < 0.015) smoothed_current = 0.0;

    // طباعة السيريال بالصيغة القياسية الموحدة للبايثون
    Serial.print("Speed_PWM:"); Serial.print(currentSpeed);
    Serial.print(" | RPM:"); Serial.print(rpm, 1);
    Serial.print(" | Vib_X:"); Serial.print(a.acceleration.x, 2);
    Serial.print(" | Vib_Y:"); Serial.print(a.acceleration.y, 2);
    Serial.print(" | Vib_Z:"); Serial.print(a.acceleration.z, 2);
    Serial.print(" | Temp:"); Serial.print(tempC, 2);
    Serial.print(" | Current:"); Serial.println(smoothed_current, 3);

    // [WiFi ADD] تحديث متغيرات WiFi بأحدث قيم الحساسات
    wifi_ax       = a.acceleration.x;
    wifi_ay       = a.acceleration.y;
    wifi_az       = a.acceleration.z;
    wifi_tempC    = tempC;
    wifi_current  = smoothed_current;

    lastSerial_Millis = currentMillis;
  }

  // =======================================================
  // [WiFi ADD] إرسال البيانات لـ Flask كل 300ms
  // (توقيت منفصل لا يؤثر على السيريال أو الـ RPM)
  // =======================================================
  if (currentMillis - lastWiFi_Millis >= 300) {
    sendToFlask(currentSpeed, rpm,
                wifi_ax, wifi_ay, wifi_az,
                wifi_tempC, wifi_current);
    lastWiFi_Millis = currentMillis;
  }

}
